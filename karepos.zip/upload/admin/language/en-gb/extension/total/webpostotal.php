<?php
// Heading
$_['heading_title']    = 'KarePos Taksit/Tek Çekim Toplamı';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Taksit/Tek Çekim başarıyla değiştirildi!';
$_['text_edit']        = 'Taksit/Tek Çekim toplamını düzenle';

// Entry
$_['entry_status']     = 'Durumu:';
$_['entry_sort_order'] = 'Sıralama:';
$_['entry_single_ratio'] = '<span title="" data-toggle="tooltip" data-original-title="Tek ÇEkimlerde uygulanacak oranı giriniz.Örnek1(Komisyon eklemek için): 2.50 Örnek2(İndirim yapmak için): -5.00">Tek Çekim Komisyon/İndirim Oranı:</span>';

// Error
$_['error_permission'] = 'Uyarı: Taksit/Tek Çekim toplamını düzenleme yetkisine sahip değilsiniz!';