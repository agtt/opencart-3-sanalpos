<?php
class get7243dModel {
}