<?php
class get724Classic {
}