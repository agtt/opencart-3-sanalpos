<?php
class get7243dPay {
}