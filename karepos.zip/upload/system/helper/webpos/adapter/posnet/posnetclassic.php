<?php
class posnetClassic {
}