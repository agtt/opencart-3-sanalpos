<?php
class posnet3DPay {
}