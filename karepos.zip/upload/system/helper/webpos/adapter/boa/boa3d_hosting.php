<?php
class boa3dHosting {
}