<?php
$_['text_total'] = 'Taksit Toplamı';
$_['text_single_positive'] = 'Tek Çekim Komisyonu';
$_['text_single_negative'] = 'Tek Çekim İndirimi';
$_['text_no_commision'] = 'Tek Çekim';